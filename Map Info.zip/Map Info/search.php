<?php
// include('config.php');

$servername="localhost";
$mysql_user="root";
$mysql_pass="";
$dbname="map_info";
$conn=mysqli_connect($servername,$mysql_user,$mysql_pass,$dbname);


?>

<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<title>Search</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- LINEARICONS -->
		<!-- <link rel="stylesheet" href="fonts/linearicons/style.css"> -->
		
		<!-- STYLE CSS -->
        <link rel="stylesheet" href="css/style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
		<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
		<!-- <script type="text/javascript" src="jquery-3.4.1.min.js"></script> -->
</head>
<body>
    <br>
    <br>
    <h3>Your Search Results</h3>
    <h3>Click Plot Links to view Plots</h3>
    <form action="results.php" method="POST">  
    <?php
        //  echo $project_id =$_POST['project_id'];
    if(isset($_POST['search'])){

    $project_id = $_POST['project_id'];
    $residential_id = $_POST['residential_id'];
    $precient_id    = $_POST['precinct_id'];
    $roadstreet_id  = $_POST['roadstreet_id'];
    $plot_id         = $_POST['plot_id'];
   
    $sql = "SELECT  project.id , project.project_name , 
    residential.id , residential.residential_name , residential.project_id ,
    precinct.id , precinct.precinct_name , precinct.project_id , precinct.residential_id ,
    roadstreet.id , roadstreet.roadstreet_name , roadstreet.precinct_id ,
    plot.id , plot.plot_name , plot.roadstreet_id
    FROM project 
    JOIN residential on project.id = residential.project_id
    JOIN precinct ON residential.id= precinct.residential_id
    JOIN roadstreet on precinct.id = roadstreet.precinct_id 
    JOIN plot ON roadstreet.id = plot.roadstreet_id
    WHERE 
    project.id= '$project_id'  AND 
    residential.id = '$residential_id' AND
    precinct.id = '$precient_id' AND
    roadstreet.id = '$roadstreet_id' ";
    // print_r($sql);
    // echo $sql;
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0)
    {
  
    ?> 
    <table class="table table-striped table-bordered">
    
    <thead>
     <tr>
     <th>S.no</th>
     <th>Project Name</th>
    <th>Residential Name</th>
    <th>Precient Name</th>
    <th>Roadstreet Name</th>
     <th>Plot Name</th>
     <th>Plot Link</th>
    </tr>
    </thead>
     <?PHP
     $sno = 1;
      //OUTPUT DATA OF EACH ROW
      while($row = mysqli_fetch_array($result)){
       
    ?>
    <tbody>
    <tr>
    <?php echo "<td>".($sno++)."</td>"; ?>
     <td> <?php echo $row['project_name']; ?>  </td>
     <td> <?php echo $row['residential_name']; ?>  </td>
     <td><?php echo $row['precinct_name']; ?></td>
    <td><?php echo $row['roadstreet_name']; ?></td>
    <td><?php echo $row['plot_name']; ?></td>
    <td><a href="website/<?php echo $row['plot_name'];?>.php">Click to View Plot</a> </td>
    
    
    </tr>
    </tbody>
   
    <?php } 
    ?>
    </table>
      </form>
      
    <br>
  <?php } else { ?>

  <h4><center>0 RESULTS</center> </h4>

  <?php } 
  }
   ?>
</body>
</html>