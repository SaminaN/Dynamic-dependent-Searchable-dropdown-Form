<?php

$connect = new PDO("mysql:host=localhost;dbname=map_info", "root", "");

if(isset($_POST["type"]))
{
 if($_POST["type"] == "category_data")
 {
  // $query = "SELECT * FROM tbl_industry 
  // ORDER BY industry_name ASC";
  $query = "SELECT * FROM project ORDER BY project_name ASC";
  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["id"],
    'name'  => $row["project_name"]
   );
  }
  echo json_encode($output);
 }
 else
 {
  // $query = "
  // SELECT * FROM tbl_sub_industry 
  // WHERE industry_id = '".$_POST["category_id"]."' 
  // ORDER BY sub_industry_name ASC
  // ";
  $query = "
  SELECT * FROM residential 
  WHERE project_id = '".$_POST["category_id"]."' 
  ORDER BY residential_name ASC
  ";
  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["id"],
    'name'  => $row["residential_name"]
   );
  }
  echo json_encode($output);
 }
}

?>
