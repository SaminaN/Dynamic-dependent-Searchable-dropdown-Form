<?php 

include "config.php";

$request = 0;

// if(isset($_POST['request'])){
//    $request = $_POST['request'];
// }
if(isset($_POST['request']))
{
   if($_POST['request'] == "category_data")
   {

// Fetch state list by countryid
   // if($request == 1){
   $countryid = $_POST['countryid'];

   $stmt = $conn->prepare("SELECT * FROM residential WHERE project_id=:project ORDER BY residential_name");
   $stmt->bindValue(':project', (int)$countryid, PDO::PARAM_INT);

   $stmt->execute();
   $statesList = $stmt->fetchAll();

   $response = array();
   foreach($statesList as $state)
   {
      $response[] = array(
            "id" => $state['id'],
            "name" => $state['residential_name']
         );
   }

   echo json_encode($response);
   // exit;
   // }
   }
else
{



// Fetch city list by stateid
// if($request == 2){
   $stateid = $_POST['stateid'];

   $stmt = $conn->prepare("SELECT * FROM precinct WHERE project_id=:residential ORDER BY precinct_name");
   $stmt->bindValue(':residential', (int)$stateid, PDO::PARAM_INT);

   $stmt->execute();
   $statesList = $stmt->fetchAll();

   $response = array();
   foreach($statesList as $state)
   {
      $response[] = array(
            "id" => $state['id'],
            "name" => $state['precinct_name']
         );
   }

   echo json_encode($response);
   // exit;
   // } 
}


if($request == 3){
   $prcnid = $_POST['prcnid'];

   $stmt = $conn->prepare("SELECT * FROM roadstreet WHERE precinct_id=:precinct ORDER BY roadstreet_name");
   $stmt->bindValue(':precinct', (int)$prcnid, PDO::PARAM_INT);

   $stmt->execute();
   $statesList = $stmt->fetchAll();

   $response = array();
   foreach($statesList as $state){
      $response[] = array(
            "id" => $state['id'],
            "name" => $state['roadstreet_name']
         );
   }

   echo json_encode($response);
   exit;
}
if($request == 4){
   $roadid = $_POST['roadid'];

   $stmt = $conn->prepare("SELECT * FROM plot WHERE roadstreet_id=:roadstreet ORDER BY plot_name");
   $stmt->bindValue(':roadstreet', (int)$roadid, PDO::PARAM_INT);

   $stmt->execute();
   $statesList = $stmt->fetchAll();

   $response = array();
   foreach($statesList as $state){
      $response[] = array(
            "id" => $state['id'],
            "name" => $state['plot_name']
         );
   }

   echo json_encode($response);
   exit;
   }


 
}