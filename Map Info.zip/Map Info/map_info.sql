-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2021 at 11:33 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `map_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `plot`
--

CREATE TABLE `plot` (
  `id` int(11) NOT NULL,
  `plot_name` varchar(25) NOT NULL,
  `roadstreet_id` int(11) NOT NULL,
  `plot_url` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plot`
--

INSERT INTO `plot` (`id`, `plot_name`, `roadstreet_id`, `plot_url`) VALUES
(1, 'Plot 1', 1, 'http://novawatches.pk/location1.php'),
(2, 'Plot 2', 1, 'http://novawatches.pk/location2.php'),
(3, 'Plot 3', 2, 'http://novawatches.pk/location3.php'),
(4, 'Plot 4', 2, 'http://novawatches.pk/location4.php'),
(5, 'Plot 5', 2, 'http://novawatches.pk/location5.php'),
(6, 'Plot 6', 7, 'http://novawatches.pk/location6.php'),
(7, 'Plot 7', 7, 'http://novawatches.pk/location7.php'),
(8, 'Plot 8', 7, 'http://novawatches.pk/location8.php'),
(9, 'Plot 9', 7, 'http://novawatches.pk/location9.php'),
(10, 'Plot 10', 7, 'http://novawatches.pk/location10.php'),
(11, 'Plot 11', 2, 'http://novawatches.pk/location11.php'),
(12, 'Plot 12', 2, 'http://novawatches.pk/location12.php'),
(13, 'Plot 13', 13, 'http://novawatches.pk/location13.php'),
(14, 'Plot 14', 14, 'http://novawatches.pk/location14.php'),
(15, 'Plot 15', 15, 'http://novawatches.pk/location15.php'),
(16, 'Plot 16', 16, 'http://novawatches.pk/location16.php'),
(17, 'Plot 17', 17, 'http://novawatches.pk/location17.php'),
(18, 'Plot 18', 18, 'http://novawatches.pk/location18.php'),
(19, 'Plot 19', 19, 'http://novawatches.pk/location19.php'),
(20, 'Plot 20', 20, 'http://novawatches.pk/location20.php'),
(26, 'Plot 26', 26, 'website.com/id.php');

-- --------------------------------------------------------

--
-- Table structure for table `precinct`
--

CREATE TABLE `precinct` (
  `id` int(11) NOT NULL,
  `precinct_name` varchar(25) NOT NULL,
  `project_id` int(11) NOT NULL,
  `residential_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `precinct`
--

INSERT INTO `precinct` (`id`, `precinct_name`, `project_id`, `residential_id`) VALUES
(1, 'Precinct 1', 1, 1),
(2, 'Precinct 2', 1, 1),
(3, 'Precinct 3', 1, 2),
(4, 'Precinct 4', 1, 2),
(5, 'Precinct 5', 1, 2),
(21, 'Precinct 1', 2, 3),
(22, 'Precinct 2', 2, 3),
(23, 'Precinct 3', 2, 3),
(24, 'Precinct 4', 2, 4),
(25, 'Precinct 5', 2, 4),
(31, 'Precinct 1', 3, 5),
(32, 'Precinct 2', 3, 5),
(33, 'Precinct 3', 3, 5),
(34, 'Precinct 4', 3, 6),
(35, 'Precinct 5', 3, 6),
(41, 'Precinct 1', 4, 7),
(42, 'Precinct 2', 4, 7),
(43, 'Precinct 3', 4, 8),
(44, 'Precinct 4', 4, 8),
(45, 'Precinct 5', 4, 8),
(51, 'Precinct 1', 5, 9),
(52, 'Precinct 2', 5, 9),
(53, 'Precinct 3', 5, 10),
(54, 'Precinct 4', 5, 10),
(55, 'Precinct 5', 5, 10);

-- --------------------------------------------------------

--
-- Table structure for table `precinct1`
--

CREATE TABLE `precinct1` (
  `id` int(11) NOT NULL,
  `precinct_name` varchar(25) NOT NULL,
  `project_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `precinct1`
--

INSERT INTO `precinct1` (`id`, `precinct_name`, `project_id`) VALUES
(1, 'Precinct 1', 1),
(2, 'Precinct 2', 1),
(3, 'Precinct 3', 1),
(4, 'Precinct 4', 1),
(5, 'Precinct 5', 1),
(21, 'Precinct 1', 2),
(22, 'Precinct 2', 2),
(23, 'Precinct 3', 2),
(24, 'Precinct 4', 2),
(25, 'Precinct 5', 2),
(31, 'Precinct 1', 3),
(32, 'Precinct 2', 3),
(33, 'Precinct 3', 3),
(34, 'Precinct 4', 3),
(35, 'Precinct 5', 3),
(41, 'Precinct 1', 4),
(42, 'Precinct 2', 4),
(43, 'Precinct 3', 4),
(44, 'Precinct 4', 4),
(45, 'Precinct 5', 4),
(51, 'Precinct 1', 5),
(52, 'Precinct 2', 5),
(53, 'Precinct 3', 5),
(54, 'Precinct 4', 5),
(55, 'Precinct 5', 5);

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `project_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `project_name`) VALUES
(1, 'Project 1'),
(2, 'Project 2'),
(3, 'Project 3'),
(4, 'Project 4'),
(5, 'Project 5');

-- --------------------------------------------------------

--
-- Table structure for table `residential`
--

CREATE TABLE `residential` (
  `id` int(11) NOT NULL,
  `residential_name` varchar(25) NOT NULL,
  `project_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `residential`
--

INSERT INTO `residential` (`id`, `residential_name`, `project_id`) VALUES
(1, 'Residential', 1),
(2, 'Commercial', 1),
(3, 'Residential', 2),
(4, 'Commercial', 2),
(5, 'Residential', 3),
(6, 'Commercial', 3),
(7, 'Residential', 4),
(8, 'Commercial', 4),
(9, 'Residential', 5),
(10, 'Commercial', 5);

-- --------------------------------------------------------

--
-- Table structure for table `roadstreet`
--

CREATE TABLE `roadstreet` (
  `id` int(11) NOT NULL,
  `roadstreet_name` varchar(25) NOT NULL,
  `precinct_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roadstreet`
--

INSERT INTO `roadstreet` (`id`, `roadstreet_name`, `precinct_id`) VALUES
(1, 'Street 1', 1),
(2, 'Road 1', 1),
(3, 'Street 2', 1),
(4, 'Street 3', 1),
(5, 'Street 4', 1),
(6, 'Street 5', 1),
(7, 'Road 2', 1),
(8, 'Road 3', 1),
(9, 'Road 4', 1),
(10, 'Road 5', 1),
(11, 'Street 1', 2),
(12, 'Street 2', 2),
(13, 'Street 3', 2),
(14, 'Street 4', 2),
(15, 'Street 5', 2),
(16, 'Road 1', 2),
(17, 'Road 2', 2),
(18, 'Road 3', 2),
(19, 'Road 4', 2),
(20, 'Road 5', 2),
(21, 'Street 1', 3),
(22, 'Street 2', 3),
(23, 'Street 3', 3),
(24, 'Street 4', 3),
(25, 'Road 1', 4),
(26, 'Street 5', 3),
(411, 'Street 1', 4),
(412, 'Street 2', 4),
(413, 'Street 3', 4),
(414, 'Street 4', 4),
(415, 'Street 5', 4),
(511, 'Street 1', 5),
(512, 'Street 2', 5),
(513, 'Street 3', 5),
(514, 'Street 4', 5),
(515, 'Street 5', 5),
(3121, 'Road 1', 3),
(3122, 'Road 2', 3),
(3123, 'Road 3', 3),
(3124, 'Road 4', 3),
(3125, 'Road 5', 3),
(4121, 'Road 1', 4),
(4122, 'Road 2', 4),
(4123, 'Road 3', 4),
(4124, 'Road 4', 4),
(4125, 'Road 5', 4),
(5121, 'Road 1', 5),
(5122, 'Road 2', 5),
(5123, 'Road 3', 5),
(5124, 'Road 4', 5),
(5125, 'Road 5', 5),
(44403, 'Road 1', 4),
(44404, 'Road 2', 4),
(44405, 'Street 1', 4),
(44406, 'Street 3', 4),
(44407, 'Road 1', 5),
(44408, 'Road 2', 5),
(44409, 'Street 1', 5),
(44410, 'Street 2', 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `plot`
--
ALTER TABLE `plot`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roadstreet_id` (`roadstreet_id`);

--
-- Indexes for table `precinct`
--
ALTER TABLE `precinct`
  ADD PRIMARY KEY (`id`),
  ADD KEY `residential_id` (`residential_id`);

--
-- Indexes for table `precinct1`
--
ALTER TABLE `precinct1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `precinct_ibfk_1` (`project_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `residential`
--
ALTER TABLE `residential`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `roadstreet`
--
ALTER TABLE `roadstreet`
  ADD PRIMARY KEY (`id`),
  ADD KEY `precinct_id` (`precinct_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `plot`
--
ALTER TABLE `plot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `plot`
--
ALTER TABLE `plot`
  ADD CONSTRAINT `plot_ibfk_1` FOREIGN KEY (`roadstreet_id`) REFERENCES `roadstreet` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `precinct`
--
ALTER TABLE `precinct`
  ADD CONSTRAINT `precinct_ibfk_1` FOREIGN KEY (`residential_id`) REFERENCES `residential` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `precinct1`
--
ALTER TABLE `precinct1`
  ADD CONSTRAINT `precinct1_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `residential` (`project_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `residential`
--
ALTER TABLE `residential`
  ADD CONSTRAINT `residential_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `roadstreet`
--
ALTER TABLE `roadstreet`
  ADD CONSTRAINT `roadstreet_ibfk_1` FOREIGN KEY (`precinct_id`) REFERENCES `precinct1` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
