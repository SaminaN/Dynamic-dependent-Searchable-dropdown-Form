<?php

$connect = new PDO("mysql:host=localhost;dbname=map_info", "root", "");

if(isset($_POST["type"]))
{
   
 if($_POST["type"] == "category_data")
 {
  // $query = "SELECT * FROM tbl_industry 
  // ORDER BY industry_name ASC";
  $query = "SELECT * FROM project ORDER BY project_name ASC";
  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["id"],
    'name'  => $row["project_name"]
   );
  }
  echo json_encode($output);
 }
 else if($_POST["type"] == "precinct_data"){
    $query = "SELECT * FROM precinct WHERE project_id = '".$_POST["category_id"]."'";

  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["id"],
    'name'  => $row["precinct_name"]
   );
  }
  echo json_encode($output);
 }
// street_data SELECT `id`, `roadstreet_name`, `precinct_id` FROM `roadstreet` WHERE 1
 else if($_POST["type"] == "street_data")
 {
    $query = "SELECT * FROM roadstreet WHERE precinct_id = '".$_POST["category_id"]."'";

  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["id"],
    'name'  => $row["roadstreet_name"]
   );
  }
  echo json_encode($output);
 }
 // plot data SELECT `id`, `plot_name`, `roadstreet_id`, `plot_url` FROM `plot` WHERE 1
else if($_POST["type"] == "plot_data")
 {
    $query = "SELECT * FROM plot WHERE roadstreet_id = '".$_POST["category_id"]."'";

  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["id"],
    'name'  => $row["plot_name"]
   );
  }
  echo json_encode($output);
 }



 else
 {
  // $query = "
  // SELECT * FROM tbl_sub_industry 
  // WHERE industry_id = '".$_POST["category_id"]."' 
  // ORDER BY sub_industry_name ASC
  // ";
  $query = "
  SELECT * FROM residential 
  WHERE project_id = '".$_POST["category_id"]."' 
  ORDER BY residential_name ASC
  ";
  $statement = $connect->prepare($query);
  $statement->execute();
  $data = $statement->fetchAll();
  foreach($data as $row)
  {
   $output[] = array(
    'id'  => $row["id"],
    'name'  => $row["residential_name"]
   );
  }
  echo json_encode($output);
 }
}

?>