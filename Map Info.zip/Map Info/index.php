<?php
include('config.php');
?>

    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8">
        <title>Search</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- LINEARICONS -->
        <link rel="stylesheet" href="fonts/linearicons/style.css">

        <!-- STYLE CSS -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <!-- jquery script -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script type="text/javascript" src="jquery-3.4.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/css/bootstrap-select.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/js/bootstrap-select.min.js"></script>
 

    </head>

    <body>

        <div class="wrapper">
            <div class="inner">
               
                    <form action="index.php" method="POST">
                    <h3>Choose the best Option!</h3>
                    <h3>Must Select all fields </h3>
                        <div class="form-group">
                            <label>Select Project</label>
                            <select name="category_item" id="category_item"autocomplete="off"  class="form-control input-lg" data-live-search="true" title="Select Project" required="required" />
					  <option value="" selectted>Select Project</option></a>
		          	
	
</select>
                        </div>
                        <div class="form-group">
                            <label>Select Residential</label>
                            <select name="sub_category_item" id="sub_category_item" class="form-control input-lg" data-live-search="true" title="Select Residential"required="required" />
			          	<option value="" class="form-control">Select Residential</option>
</select>
                        </div>
                        <div class="form-group">
                            <label>Select Precient</label>
                            <select name="sub_presinct" id="sub_presinct" class="form-control input-lg" data-live-search="true" title="Select Precient" required="required" />
							<option value="" class="form-control">Select Precient</option>
</select>
                        </div>
                        <div class="form-group">
                            <label>Road/Street</label>
                            <select  name="sub_street" id="sub_street" class="form-control input-lg" data-live-search="true" title="Select Road/Street" required="required" />
						<option value="" class="form-control">Select Road </option>
</select>
                        </div>
                        <div class="form-group">
                            <label>Select Plot View</label>
                            <select name="sub_plot" id="sub_plot" class="form-control input-lg" data-live-search="true" title="Select Plot" required="required" />
						<option value="" class="form-control">Select Plot </option>
</select>

                        </div>
                        
                            <button type="submit" name="search" class="btn btn-primary"><span>Search</span></button>

                            <button type="submit" name="Reset" id="Reset" onclick="reset();" class="btn btn-primary" value="Reset" >Reset Form </button>
                        
                    </form>
            </div>
        </div>	
        <!-- Script -->
<script type="text/javascript">
           
$(document).ready(function(){

  $('#category_item').selectpicker();

  $('#sub_category_item').selectpicker();
  $('#sub_presinct').selectpicker();
  $('#sub_street').selectpicker();
  $('#sub_plot').selectpicker();



  load_data('category_data');

  function load_data(type, category_id = '')
  {
    $.ajax({
      url:"face_load_data.php",
      method:"POST",
      data:{type:type, category_id:category_id},
      dataType:"json",
      success:function(data)
      {
        console.log(data);
        var html = '';
        for(var count = 0; count < data.length; count++)
        {
          html += '<option value="'+data[count].id+'">'+data[count].name+'</option>';
        }
        if(type == 'category_data')
        {
           
          $('#category_item').html(html);
          $('#category_item').selectpicker('refresh');
        }
        else
        {

          $('#sub_category_item').html(html);
          $('#sub_category_item').selectpicker('refresh');
        }
      }
    })
  }

  $(document).on('change', '#category_item', function(){
    var category_id = $('#category_item').val();
    load_data('sub_category_data', category_id);
  });
  
  // sub_category_item
  $(document).on('change', '#sub_category_item', function(){
    var category_id = $('#sub_category_item').val();
    
    $.ajax({
      url:"face_load_data.php",
      method:"POST",
      data:{type:'precinct_data', category_id:category_id},
      success:function(data)
      {
        var html = '';
        JSON.parse(data).forEach( function(e, i) {
          html += '<option value="'+e.id+'">'+e.name+'</option>';
        });
        $('#sub_presinct').html(html);
         $('#sub_presinct').selectpicker('refresh');
      },
      error:function(xhr, status, error){
        console.log(status);
      }
    })
  });

  // #sub_presinct

  $(document).on('change', '#sub_presinct', function(){
    var category_id = $('#sub_presinct').val();
    
    $.ajax({
      url:"face_load_data.php",
      method:"POST",
      data:{type:'street_data', category_id:category_id},
      success:function(data)
      {
        var html = '';
        JSON.parse(data).forEach( function(e, i) {
          html += '<option value="'+e.id+'">'+e.name+'</option>';
        });
        $('#sub_street').html(html);
         $('#sub_street').selectpicker('refresh');
      },
      error:function(xhr, status, error){
        console.log(status);
      }
    })
  });


  // sub_plot

  $(document).on('change', '#sub_street', function(){
    var category_id = $('#sub_street').val();
    
    $.ajax({
      url:"face_load_data.php",
      method:"POST",
      data:{type:'plot_data', category_id:category_id},
      success:function(data)
      {
        var html = '';
        JSON.parse(data).forEach( function(e, i) {
          html += '<option value="'+e.id+'">'+e.name+'</option>';
        });
        $('#sub_plot').html(html);
         $('#sub_plot').selectpicker('refresh');
      },
      error:function(xhr, status, error){
        console.log(status);
      }
    })
  });
  
});

</script>

        
<?php

if(isset($_POST['search'])){
    $project_id = $_POST['category_item'];
    $residential_id = $_POST['sub_category_item'];
    $precient_id    = $_POST['sub_presinct'];
    $roadstreet_id  = $_POST['sub_street'];
    $plot_id   = $_POST['sub_plot'];
   
    // if ($project_id = 0 )
    // {
    //     echo '<script>alert("Select Project Name")</script>'; 
 
    // } 

    
    // if (empty($_POST['residential_id'])) {
    //     echo 'alert(Select Residential)'; 
    // } else { 
    //     $residential_id = $_POST['residential_id'];
    // }
    
    // if (empty($_POST['pecinct_id'])) {
    //     echo 'alert(Select Presient)'; 
    // } else { 
    //     $precient_id    = $_POST['precinct_id'];
    // }
   
    // if (empty($_POST['roadstreet_id'])) {
    //     echo 'alert(Select Road or Street)'; 
    // } else { 
    //     $roadstreet_id  = $_POST['roadstreet_id'];
    // }
   
    // if (empty($_POST['plot_id'])) {
    //     echo 'alert( Select Plot)'; 
    // } else { 
    //     $plot_id   = $_POST['plot_id'];
    // }
	
    $sql = $conn->prepare("SELECT   project.project_name , 
     residential.residential_name , residential.project_id ,
     precinct.precinct_name , precinct.project_id , 
     roadstreet.roadstreet_name , roadstreet.precinct_id ,
    plot.id , plot.plot_name , plot.roadstreet_id,plot.plot_url
    FROM project 
    JOIN residential on project.id = residential.project_id
    JOIN precinct ON residential.id= precinct.project_id
    JOIN roadstreet on precinct.id = roadstreet.precinct_id 
    JOIN plot ON roadstreet.id = plot.roadstreet_id
    WHERE 
    project.id= '$project_id'  AND 
    residential.id = '$residential_id' AND
    precinct.id = '$precient_id' AND
	roadstreet.id = '$roadstreet_id' AND
	plot.id = '$plot_id' ");

     $sql->execute();
    $statesList = $sql->fetchAll();
   
foreach ($statesList as $row) {
	
	$plot_id = $row['id'];
	echo $plot_link = $row['plot_url'];

     
	echo "<script>window.location='$plot_link' </script>";

} 
 } ?>

    </body>

    </html>